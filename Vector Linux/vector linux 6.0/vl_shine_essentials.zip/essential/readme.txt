These 2 files are meant to be used only when the final image needs to be exported in 8 bits (256 colours):

vl_logo_shine_transp_blueglobe.png 
vl_logo_shine_transp2_blueglobe.png

(Examples of this are the bootable CD splash and the lowest lilo boot image)


Copyright Vector Linux.